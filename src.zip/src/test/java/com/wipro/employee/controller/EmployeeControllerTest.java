package com.wipro.employee.controller;
import static org.hamcrest.CoreMatchers.any;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.wipro.employee.dto.request.Employee;
import com.wipro.employee.service.EmployeeService;

import tools.jackson.databind.ObjectMapper;
@WebMvcTest(EmployeeController.class)
public class EmployeeControllerTest {
	@MockitoBean
	private EmployeeService employeeService;
	@Autowired
	private MockMvc mockMvc;
	@Autowired
	private ObjectMapper objectMapper;
	@Test
	void testSaveEmployee() throws Exception {
		Employee emp = new Employee("bhagya", "sri", "bhagya@gmail.com");
		when(employeeService.saveEmployee((any()))).thenReturn(emp);
		mockMvc.perform(post("/api/v1/employees")
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(emp)))
		.andExpect(status().isCreated())
		.andExpect(jsonPath("$.firstName").value("bhagya"));
	}
	@Test
	void testFindById() throws Exception {
	    Employee emp = new Employee("bhagya", "sri", "bhagya@gmail.com");
	    when(employeeService.findById(1)).thenReturn(Optional.of(emp));

	    mockMvc.perform(get("/api/v1/employees/1")
	            .contentType(MediaType.APPLICATION_JSON))
	        .andExpect(status().isOk())
	        .andExpect(jsonPath("$.firstName").value("bhagya"))
	        .andExpect(jsonPath("$.lastName").value("sri"))
	        .andExpect(jsonPath("$.email").value("bhagya@gmail.com"));
	}
}
