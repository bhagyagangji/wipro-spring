package com.wipro.employee.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.wipro.employee.dto.request.Employee;
import com.wipro.employee.exceptions.EmployeeNotFoundException;
import com.wipro.employee.repository.EmployeeRepository;

@ExtendWith(MockitoExtension.class)
public class EmployeeServiceTest {
	@Mock
	private EmployeeRepository repo;
	@InjectMocks
	private EmployeeServiceImpl service;
	@Test
	void testSaveEmployee() throws Exception{
		Employee emp = new Employee("bhagya", "sri", "bhagya@gmail.com");
		when(repo.save(emp)).thenReturn(emp);
		Employee saved = service.saveEmployee(emp);
		assertEquals("bhagya", saved.getFirstName());
		Mockito.verify(repo).save(emp);
	}
	@Test
	void testFindById() throws Exception{
		Employee emp = new Employee("bhagya", "sri", "bhagya@gmail.com");
		when(repo.findById(1)).thenReturn(Optional.of(emp));
		Employee res = service.findById(1)
						.orElseThrow(
							()-> new EmployeeNotFoundException("Employee Not Found : " + 1));
		assertEquals("bhagya", res.getFirstName());
	}
	@Test
	void testFindAll() throws Exception {
		List<Employee> mockEmployees = List.of(
				new Employee("bhagya","sri","bhagya@gmail.com"),
				new Employee("bhagya1","sri1","bhagya1@gmail.com")
		);
		when(repo.findAll()).thenReturn(mockEmployees);
		List<Employee> res = service.findAll();
		assertEquals(2,res.size());
		assertEquals(res.get(0).getFirstName(), "bhagya");
		Mockito.verify(repo, Mockito.times(1)).findAll();
	}
}
