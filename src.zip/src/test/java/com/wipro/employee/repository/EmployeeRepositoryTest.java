package com.wipro.employee.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;
import org.springframework.boot.jdbc.test.autoconfigure.AutoConfigureTestDatabase;
import org.springframework.boot.jpa.test.autoconfigure.TestEntityManager;

import com.wipro.employee.dto.request.Employee;
import com.wipro.employee.exceptions.EmployeeNotFoundException;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class EmployeeRepositoryTest {
	@Autowired
	private EmployeeRepository repo;
	
	@Test
	void testSaveEmployee() throws Exception {
		Employee emp = new Employee("bhagya", "sri", "bhagya@gmail.com");
		Employee saved  = repo.save(emp);
		assertThat(saved.getEmployeeID()).isNotNull();
		assertThat(saved.getEmail()).isEqualTo("bhagya@gmail.com");
	}
	@Test
	void testFindById() throws Exception{
		Employee emp = new Employee("bhagya", "sri", "bhagya@gmail.com");
		repo.save(emp);
		Optional<Employee> res = repo.findById(1);
		assertThat(res).isPresent();
		assertThat(res.get().getFirstName()).isEqualTo("bhagya");
	}
	@Test
	void testFindAll() throws Exception {
		List<Employee> mockEmployees = List.of(
				new Employee("bhagya","sri","bhagya@gmail.com"),
				new Employee("bhagya1","sri1","bhagya1@gmail.com")
		);
		for(Employee e: mockEmployees) {
			repo.save(e);
		}
		
		List<Employee> res = repo.findAll();
		assertEquals(4, res.size());
	}
}
