package com.wipro.employee.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.employee.dto.request.Employee;
import com.wipro.employee.exceptions.EmployeeNotFoundException;
import com.wipro.employee.service.EmployeeService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.transaction.Transactional;

@Tag(name = "Employee Controller",
description = "Manages employee CRUD operations")
@RequestMapping("api/v1/employees")
@RestController
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;
	@Operation(summary = "Create new employee")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Employee created")
    })
	
	@Transactional
	@PostMapping
	public ResponseEntity<Employee> saveEmployee(@RequestBody Employee employee){
		return new ResponseEntity<Employee>(
				employeeService.saveEmployee(employee),HttpStatus.CREATED);
	}
	
	
	@Operation(summary = "Get employee by ID", description = "Fetch an employee using its ID")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Employee found"),
        @ApiResponse(responseCode = "404", description = "Employee not found")
    })
	@GetMapping("/{id}")
	public ResponseEntity<Employee> findEmployeeById(@PathVariable int id) {
		Optional<Employee> emp = employeeService.findById(id);
		if(emp.isPresent())
			return new ResponseEntity<Employee>(emp.get(),HttpStatus.OK);
		else
			throw new EmployeeNotFoundException("Employee not Found " + id);
	}
	
	@Operation(summary = "Get all employees", description = "Returns a list of all employees")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Successful retrieval"),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
	
	@GetMapping
	public ResponseEntity<List<Employee>> findAll() {
		return new ResponseEntity<List<Employee>>(employeeService.findAll(),HttpStatus.OK);
	}
	@GetMapping("/firstname/{firstName}")
	public ResponseEntity<Employee> findByFirstName(@PathVariable String firstName) {
		Optional<Employee> emp = employeeService.findByFirstName(firstName);
		if(emp.isPresent())
			return new ResponseEntity<Employee>(emp.get(),HttpStatus.OK);
		else
			throw new EmployeeNotFoundException("Employee Not Found: " + firstName);
	}
	
	@Operation(summary = "Delete an Employee", description = "Remove a perticular Employee with given id")
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteById(@PathVariable int id){
		if(employeeService.findById(id).isPresent()) {
			employeeService.deleteById(id);
//			ResponseEntity<String> res = new ResponseEntity<String>("Employee deleted",HttpStatus.OK);
			return ResponseEntity.noContent().build();
		}
		else
			throw new EmployeeNotFoundException("Employee Not Found" + id);
	}
}
