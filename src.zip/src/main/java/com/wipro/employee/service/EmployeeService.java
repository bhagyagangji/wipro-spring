package com.wipro.employee.service;

import java.util.List;
import java.util.Optional;

import com.wipro.employee.dto.request.Employee;
import com.wipro.employee.exceptions.EmployeeNotFoundException;

public interface EmployeeService {
	Employee saveEmployee(Employee employee);
	Optional<Employee> findById(int id) throws EmployeeNotFoundException;
	List<Employee> findAll();
	Optional<Employee> findByFirstName(String firstName) throws EmployeeNotFoundException;
	void deleteById(int id);
}
