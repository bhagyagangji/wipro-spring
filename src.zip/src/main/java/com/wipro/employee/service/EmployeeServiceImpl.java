package com.wipro.employee.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.employee.dto.request.Employee;
import com.wipro.employee.exceptions.EmployeeNotFoundException;
import com.wipro.employee.repository.EmployeeRepository;
@Service
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
	private EmployeeRepository employeeRepository;
	@Override
	public Employee saveEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}
	@Override
	public Optional<Employee> findById(int id) throws EmployeeNotFoundException {
		return employeeRepository.findById(id);
	}
	@Override
	public List<Employee> findAll() {
		return employeeRepository.findAll();
	}
	@Override
	public Optional<Employee> findByFirstName(String firstName) throws EmployeeNotFoundException{
		return employeeRepository.findByFirstName(firstName);
	}
	@Override
	public void deleteById(int id) {
		// TODO Auto-generated method stub
		employeeRepository.deleteById(id);
	}

}
