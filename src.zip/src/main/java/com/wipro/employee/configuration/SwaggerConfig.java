package com.wipro.employee.configuration;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
@Configuration
@OpenAPIDefinition(
    info = @Info(
        title = "Employee API",
        version = "1.0",
        description = "API documentation for Employee management",
        contact = @io.swagger.v3.oas.annotations.info.Contact(
        		name = "Bhagya Sri G",
        		url = "http://localhost:8090/api/v1/employees",
        		email = "bhagya@gmail.com"
        		)
        )
    )
public class SwaggerConfig {
}
