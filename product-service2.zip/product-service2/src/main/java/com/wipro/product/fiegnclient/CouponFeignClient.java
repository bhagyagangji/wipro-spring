package com.wipro.product.fiegnclient;

//import org.springframework.cloud.openfeign.FeignClient;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//
//import com.wipro.coupon.dto.Coupon;
//
//@FeignClient("COUPON-SERVICE")
//public interface CouponFeignClient {
//	@GetMapping("/api/v1/coupons/couponcode/{couponCode}")
//	public ResponseEntity<Coupon> findCouponByCouponCode
//	(@PathVariable String couponCode);
//}
