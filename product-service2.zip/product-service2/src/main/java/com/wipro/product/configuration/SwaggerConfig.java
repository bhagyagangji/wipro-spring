package com.wipro.product.configuration;

import org.springframework.context.annotation.Configuration;

//@Configuration
//@OpenAPIDefinition(
//    info = @Info(
//        title = "Product API",
//        version = "1.0",
//        description = "API documentation for Product management",
//        contact = @io.swagger.v3.oas.annotations.info.Contact(
//        		name = "Bhagya Sri G",
//        		url = "http://localhost:8080/api/v1/product",
//        		email = "bhagya@gmail.com"
//        		)
//        )
//    )
//public class SwaggerConfig {
//}
