package com.wipro.product.service;

import com.wipro.product.dto.JwtResponse;
import com.wipro.product.dto.LoginRequest;
import com.wipro.product.dto.RegisterRequest;

public interface AuthService {
	void register(RegisterRequest request);

    JwtResponse login(LoginRequest request);

}
