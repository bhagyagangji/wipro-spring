package com.wipro.product.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.wipro.product.entity.ERole;
import com.wipro.product.entity.Role;

import java.util.Optional;

public interface RoleRepository extends JpaRepository<Role, Long> {

    Optional<Role> findByName(ERole name);
}
