package com.wipro.coupon.service;

import java.util.List;
import java.util.Optional;

import com.wipro.coupon.dto.Coupon;

public interface CouponService {
	Coupon saveCoupon(Coupon coupon);
	Optional<Coupon> findCouponById(int id);
	List<Coupon> findAll();
	Optional<Coupon> findCouponByCouponCode(String couponCode);
}
