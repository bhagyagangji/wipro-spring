package com.wipro.coupon.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.wipro.coupon.dto.Coupon;
import com.wipro.coupon.repository.CouponRepository;

@Service
public class CouponServiceImpl implements CouponService{
	private CouponRepository repo;
	public CouponServiceImpl(CouponRepository repo) {
		this.repo = repo;
	}
	@Override
	public Coupon saveCoupon(Coupon coupon) {
		return repo.save(coupon);
	}
	@Override
	public Optional<Coupon> findCouponById(int id) {
		return repo.findById(id);
	}
	@Override
	public List<Coupon> findAll() {
		return repo.findAll();
	}
	@Override
	public Optional<Coupon> findCouponByCouponCode(String couponCode) {
		return repo.findByCouponCode(couponCode);
	}
	
	
}
