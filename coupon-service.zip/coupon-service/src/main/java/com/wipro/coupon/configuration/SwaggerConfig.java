package com.wipro.coupon.configuration;

import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;

@Configuration
@OpenAPIDefinition(
    info = @Info(
        title = "Coupon API",
        version = "1.0",
        description = "API documentation for Coupon management",
        contact = @io.swagger.v3.oas.annotations.info.Contact(
        		name = "Bhagya Sri G",
        		url = "http://localhost:8082/api/v1/coupons",
        		email = "bhagya@gmail.com"
        		)
        )
    )
public class SwaggerConfig {
}
