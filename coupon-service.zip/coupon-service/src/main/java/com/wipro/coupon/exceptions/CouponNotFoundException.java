package com.wipro.coupon.exceptions;

public class CouponNotFoundException extends RuntimeException{
	public CouponNotFoundException(String msg) {
		super(msg);
	}
}
