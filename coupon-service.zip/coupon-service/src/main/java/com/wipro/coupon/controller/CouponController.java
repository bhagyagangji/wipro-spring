package com.wipro.coupon.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.coupon.dto.Coupon;
import com.wipro.coupon.dto.ErrorMessage;
import com.wipro.coupon.exceptions.CouponNotFoundException;
import com.wipro.coupon.service.CouponService;

import io.swagger.v3.oas.annotations.tags.Tag;
@Tag(name = "Coupon Service Application", description = "Provides Coupon details")
@RequestMapping("api/v1/coupons")
@RestController
public class CouponController {
	private CouponService service;

	public CouponController(CouponService service) {
		this.service = service;
	}
	
	@PostMapping
	public ResponseEntity<Coupon> saveCoupon(@RequestBody Coupon coupon) {
		return new ResponseEntity<Coupon>(service.saveCoupon(coupon), HttpStatus.CREATED);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Coupon> findById(@PathVariable int id) {
		Optional<Coupon> coupon = service.findCouponById(id);
		if(coupon.isPresent())
			return new ResponseEntity<Coupon>(coupon.get(), HttpStatus.OK);
		else
			throw new CouponNotFoundException("Coupon Not Found : " + id);
	}
	
	@GetMapping
	public ResponseEntity<List<Coupon>> findAll() {
		return new ResponseEntity<List<Coupon>>(service.findAll(),HttpStatus.OK);
	}
	
	@GetMapping("/couponcode/{couponCode}")
	public ResponseEntity<Coupon> findCouponByCouponCode(@PathVariable String couponCode) {
		System.out.println("server2");
		Optional<Coupon> coupon = service.findCouponByCouponCode(couponCode);
		if(coupon.isPresent())
			return new ResponseEntity<Coupon>(coupon.get(), HttpStatus.OK);
		else
			throw new CouponNotFoundException("Coupon Not Found : " + couponCode);
	}
	
	@ExceptionHandler(CouponNotFoundException.class)
	public ResponseEntity<ErrorMessage> handleException(CouponNotFoundException e) {
		return new ResponseEntity<ErrorMessage>(new ErrorMessage(e.getMessage(), HttpStatus.NOT_FOUND), HttpStatus.NOT_FOUND);
	}

}
