package com.wipro.employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeAppSpringJdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeAppSpringJdbcApplication.class, args);
	}

}
