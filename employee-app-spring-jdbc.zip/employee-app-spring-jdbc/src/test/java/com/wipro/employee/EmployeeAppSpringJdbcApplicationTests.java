package com.wipro.employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeAppSpringJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
