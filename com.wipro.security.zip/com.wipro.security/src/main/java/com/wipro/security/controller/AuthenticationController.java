package com.wipro.security.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/auth")
@RestController
public class AuthenticationController {
	@GetMapping
	public String message() {
		return "Hello";
	}
	@GetMapping("/public")
    public String publicPage() {
        return "Anyone can see this";
    }

    @GetMapping("/private")
    public String privatePage() {
        return "You are authenticated";
    }

    @GetMapping("/admin")
    public String adminPage() {
        return "Only administrators can see this";
    }
}
