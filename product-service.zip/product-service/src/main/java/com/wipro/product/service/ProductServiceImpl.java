package com.wipro.product.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.wipro.product.dto.Product;
import com.wipro.product.exceptions.ProductNotFoundException;
import com.wipro.product.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService{
	private final ProductRepository repo;
	public ProductServiceImpl(ProductRepository repo) {
		this.repo = repo;
	}
	@Override
	public Product saveProduct(Product p) {
		return repo.save(p);
	}
	@Override
	public Optional<Product> findProductById(int id) throws ProductNotFoundException{
		return repo.findById(id);
	}
	@Override
	public List<Product> findAll() {
		return repo.findAll();
	}
	@Override
	public Optional<Product> findProductByName(String name) throws ProductNotFoundException{
		return repo.findByProductName(name);
	}
	
	
}
