package com.wipro.product.service;

import java.util.List;
import java.util.Optional;

import com.wipro.product.dto.Product;
import com.wipro.product.exceptions.ProductNotFoundException;

public interface ProductService {
	Product saveProduct(Product p);
	Optional<Product> findProductById(int id) throws ProductNotFoundException;
	List<Product> findAll();
	Optional<Product> findProductByName(String name) throws 
	ProductNotFoundException;
}
