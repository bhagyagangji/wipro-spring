package com.wipro.product.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.coupon.dto.Coupon;
import com.wipro.coupon.exceptions.CouponNotFoundException;
import com.wipro.product.dto.ErrorMessage;
import com.wipro.product.dto.Product;
import com.wipro.product.dto.ProductResponse;
import com.wipro.product.exceptions.ProductNotFoundException;
import com.wipro.product.fiegnclient.CouponFeignClient;
import com.wipro.product.service.ProductService;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.swagger.v3.oas.annotations.tags.Tag;
@Tag(name = "Product Service Application",
description = "Provides Product details")
@RequestMapping("api/v1/product")
@RestController
public class ProductController {
	
	private final ProductService service;
	@Autowired
	private CouponFeignClient couponFeignClient;
	
	public ProductController(ProductService service) {
		this.service = service;
	}
	
	@PostMapping
	ResponseEntity<Product> saveProduct(@RequestBody Product p){
		return new ResponseEntity<Product>(service.saveProduct(p),
				HttpStatus.CREATED);
	}
	
	@GetMapping("/{id}")
	ResponseEntity<Product> findProductById(@PathVariable int id) throws 
	ProductNotFoundException{
		Optional<Product> p = service.findProductById(id);
		if(p.isPresent())
			return new ResponseEntity<Product>(p.get(),HttpStatus.OK);
		else
			throw new ProductNotFoundException("Product not found id: "+ id);
	}
//	@GetMapping("/{productName}/{couponCode}")
//	ResponseEntity<Product> findProductByCouponCode
//	(@PathVariable String productName, @PathVariable String couponCode) 
//				throws ProductNotFoundException, CouponNotFoundException{
//		Optional<Product> product = service.findProductByName(productName);
//		if(product.isPresent()) {
//			Product p = product.get();
//			Object coupon = couponFeignClient.findCouponByCouponCode(couponCode).getBody();
//			
//			double price = p.getPrice();
//			double newPrice = price - ((Coupon)coupon).getDiscount();
//			p.setPrice(newPrice);
//			return new ResponseEntity<Product>(p,HttpStatus.OK);
//			
//		}
//		else
//			throw new ProductNotFoundException("Product not Found " +productName);
//	}
	
	@CircuitBreaker(name="product-service", fallbackMethod = "handleError")
	@GetMapping("/{productName}/{couponCode}")
	ResponseEntity<ProductResponse> findProductByCouponCode
	(@PathVariable String productName, @PathVariable String couponCode) 
				throws ProductNotFoundException, CouponNotFoundException{
		Optional<Product> product = service.findProductByName(productName);
		if(product.isPresent()) {
			Product p = product.get();
			Object coupon = couponFeignClient.findCouponByCouponCode(couponCode).getBody();
			double price = p.getPrice();
			double newPrice = price - ((Coupon)coupon).getDiscount();
			p.setPrice(newPrice);
			ProductResponse response = new ProductResponse();
			response.setProductName(p.getProductName());
			response.setPrice(p.getPrice());
			response.setStatus("Discount Applied");
			return new ResponseEntity<ProductResponse>(response,HttpStatus.OK);
		}
		else
			throw new ProductNotFoundException("Product not Found " +productName);
	}
	
	ResponseEntity<ProductResponse> handleError(Exception e) {
		ProductResponse response = new ProductResponse();
		response.setStatus("Coupon code is currently not active");
		return new ResponseEntity<ProductResponse>(response,HttpStatus.OK);
	}
	
	@GetMapping
	ResponseEntity<List<Product>> findAll() {
		return new ResponseEntity<List<Product>>(service.findAll(),HttpStatus.OK);
	}
	
	@ExceptionHandler(ProductNotFoundException.class)
	public ResponseEntity<ErrorMessage> handleException(ProductNotFoundException e) {
		return new ResponseEntity<ErrorMessage>(new ErrorMessage(e.getMessage(), HttpStatus.NOT_FOUND), HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(CouponNotFoundException.class)
	public ResponseEntity<ErrorMessage> handleException(CouponNotFoundException e) {
		return new ResponseEntity<ErrorMessage>(new ErrorMessage(e.getMessage(), HttpStatus.NOT_FOUND), HttpStatus.NOT_FOUND);
	}
}
