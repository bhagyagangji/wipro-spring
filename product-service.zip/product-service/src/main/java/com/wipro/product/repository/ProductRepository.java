package com.wipro.product.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wipro.product.dto.Product;
import java.util.List;
import java.util.Optional;


public interface ProductRepository extends JpaRepository<Product, Integer>{
	Optional<Product> findByProductName(String productName);
}
